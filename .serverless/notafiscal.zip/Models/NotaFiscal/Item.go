package NotaFiscal

import (
	"github.com/jinzhu/gorm"
	"time"
)

// Cadastro Itens referente aos campos da nota fiscal
type Item struct {
	gorm.Model
	Codigo       string    `gorm:"type:varchar(60)"`
	Ean          string    `gorm:"type:varchar(60)"`
	Descricao    string    `gorm:"type:varchar(100)"`
	Ncm          string    `gorm:"type:varchar(60)"`
	Cfop         string    `gorm:"type:varchar(60)"`
	Unid         string    `gorm:"type:varchar(60)"`
	Qtd          float64   `gorm:"type:decimal(19,3)"`
	VUnit        float64   `gorm:"type:decimal(19,3)"`
	VTotal       float64   `gorm:"type:decimal(19,3)"`
	DtEmit       time.Time `gorm:"type:date"`
	ModBC        int
	PICMS        float64   `gorm:"type:decimal(19,3)"`
	VBC 		 float64   `gorm:"type:decimal(19,3)"`
	VICMS        float64   `gorm:"type:decimal(19,3)"`
	VICMSDeson   float64   `gorm:"type:decimal(19,3)"`
	VBCST        float64   `gorm:"type:decimal(19,3)"`
	VST          float64   `gorm:"type:decimal(19,3)"`
	VProd        float64   `gorm:"type:decimal(19,3)"`
	VFrete       float64   `gorm:"type:decimal(19,3)"`
	VSeg         float64   `gorm:"type:decimal(19,3)"`
	VDesc        float64   `gorm:"type:decimal(19,3)"`
	VII          float64   `gorm:"type:decimal(19,3)"`
	VIPI         float64   `gorm:"type:decimal(19,3)"`
	VPIS         float64   `gorm:"type:decimal(19,3)"`
	VCOFINS      float64   `gorm:"type:decimal(19,3)"`
	VOutro       float64   `gorm:"type:decimal(19,3)"`
	VNF          float64   `gorm:"type:decimal(19,3)"`
	VTotTrib     float64   `gorm:"type:decimal(19,3)"`
	NotaFiscalID uint
}
