package tools

const PLANILHA = "Analise Inventário"
const PLANILHA_NOTA = "Notas Fiscais"

